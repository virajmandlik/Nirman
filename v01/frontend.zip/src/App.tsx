import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import PersonalizedContent from "./pages/PersonalizedContent";
import InteractiveCoding from "./pages/InteractiveCoding";
import GamifiedLearning from "./pages/GamifiedLearning";
import MultilingualAssistant from "./pages/MultilingualAssistant";
import Login from "./pages/Login";
import Register from "./pages/Register";
import LearningPathSelection from "./pages/LearningPathSelection";
import ProtectedRoute from "./components/auth/ProtectedRoute";
import { AuthProvider } from "./contexts/AuthContext";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/select-learning-path" element={<LearningPathSelection />} />
            <Route 
              path="/personalized" 
              element={
                <ProtectedRoute>
                  <PersonalizedContent />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/gamified" 
              element={
                <ProtectedRoute>
                  <GamifiedLearning />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/coding" 
              element={
                <ProtectedRoute>
                  <InteractiveCoding />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/assistant" 
              element={
                <ProtectedRoute>
                  <MultilingualAssistant />
                </ProtectedRoute>
              } 
            />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
